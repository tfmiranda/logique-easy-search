console.log('executando main popup.js');
var lang;
chrome.storage.sync.get("language", function(obj) {
    console.log('executando chrome.storage.sync');
    if (!obj.language) {
        lang = chrome.i18n.getMessage("iso");
    } else {
        lang = obj.language;
    }
});
localStorage.locale_pref || lang;
window.addEventListener('load', function(evt) {
    console.log('executando window.addEventListener');
    document.getElementById('search').addEventListener('submit', openURL);
    document.getElementById("word").placeholder = chrome.i18n.getMessage("popup");
    document.getElementById('word').focus();

});

function openURL() {
    console.log('executando openURL');
    event.preventDefault();
    var word = encodeURIComponent(document.getElementById('word').value);
    chrome.tabs.create({        
        'url': "https://wiki.logiquesistemas.com.br/index.php?search=" + word + "&go=Ir"
        //'url': "http://" + lang + ".wiktionary.org/wiki/" + word
    });
}