
# Logique Easy Search
Logique Easy Search (LES) is a Google Chrome extension that allows the user made one-step search at the various Logique Sistemas plataforms. 

*Note: This is a fork project of WiktionarySearch (https://github.com/opr/WiktionarySearch)*

### TO-DO list (in pt-BR)

OK - Fazer extensão fazer pesquisa na wiki da logique;
- Limpar projeto mantendo a funcionalidade;
- Adicionar funcionalidade do atalho de teclado;
- Adicionar contexto para busca na barra de pesquisa;
- Melhorar popup.html
- Adicionar internacionalização
- Adicionar capacidade de pesquisar também em:
	- logique wiki jira
	- jira suporte
	- redmine
- Adicioanr pagina de opcoes
	- Configurar atalho
	- Configurar idioma
	- Configurar padrao de pesquisa generica
