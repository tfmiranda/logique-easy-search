
# Logique Easy Search
Logique Easy Search (LES) is a Google Chrome extension that allows the user made one-step search at the various Logique Sistemas plataforms. 

*Note: This is a fork project of WiktionarySearch (https://github.com/opr/WiktionarySearch)*

### TO-DO list (in pt-BR)

OK   - Fazer extensão fazer pesquisa na wiki da logique;
OK   - Limpar projeto mantendo a funcionalidade;
OK   - Refinar o projeto;
OK   - Adicionar funcionalidade do atalho de teclado;
OK   - Adicionar contexto para busca na barra de pesquisa;
OK   - EXTRA - Adição de busca por seleção de texto;
FAIL - Deixar atalho teclado padrão para busca; 
		- Motivo: Google não permite, há outros meios: notificação, nova aba html etc
OK - Melhorar popup.html
OK - Adicionar internacionalização
- Adicionar capacidade de pesquisar também em:
	- logique wiki jira 
	- jira suporte (https://logiquesistemas.atlassian.net/browse/SUPORTE-XXXX)
	- redmine
- Adicioanr pagina de opcoes
	- Configurar atalho
	- Configurar idioma
	- Configurar padrao de pesquisa generica

